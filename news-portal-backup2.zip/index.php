<?php

header("location: ./views/home/");

?>