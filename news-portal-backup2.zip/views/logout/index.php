<?php
require_once "../../controller/process.php";
handleLogout();