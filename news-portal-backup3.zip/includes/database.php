<?php 

    $host = "localhost";
    $dbname = "newsportal";
    $user = "root";
    $password = "";

    $data = new mysqli($host, $user, $password, $dbname);

?>