$(document).ready(() => {
  $("#photo").change((event) => {
    $("#disPhoto").prop("src", URL.createObjectURL(event.target.files[0]));
  });
});
