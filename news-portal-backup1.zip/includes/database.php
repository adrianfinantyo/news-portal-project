<?php 

    $host = "localhost";
    $dbname = "newsportal";
    $user = "root";
    $password = "";

    $data = new PDO("mysql:host=$host; dbname=$dbname", $user, $password);

?>