# News Portal

Simple overview of use/purpose.

## Description

An in-depth paragraph about your project and overview of use.

## Authors

Contributors names and contact info

- [first]()
- [second]()
- [third]()

## Acknowledgments

Inspiration, code snippets, etc.

- [Bootstrap]()
- [Jquery]()
- [Universitas Multimedia Nusantara]()
