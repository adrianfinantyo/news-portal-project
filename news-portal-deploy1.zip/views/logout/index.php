<?php
session_start();
require_once "../../controller/process.php";
handleLogout();